We Them Media: the archive as data
==================================

Built 2026-11-01 from https://wethem.xyz.

WHAT IS IN HERE

videos.json
  One object per published video. Fields:
    id            YouTube video id
    title         the card title on the site
    eyebrow       the card eyebrow (project, place, date, runtime as shown)
    contributor   who filmed it, canonical name
    alias         the name it was published under, where that differs
                  (Pepperoni Lupin is Maceo; Moto is Aziz; Hella Tim is Tim Palka)
    place         where it was filmed
    credits       other credits on the byline
    project       project id; project_name is the display name
    runtime       as shown on the card, where known
    subject       the person interviewed, only where they say their name on camera
    subject_age, subject_place
    question      the weekly question the video answers, where it answers one
    verified      the date the record was checked against the page

people.json
  One object per contributor, derived from videos.json: name, aliases,
  places, projects, pieces (video ids).

transcripts/<id>.txt
  The transcript of each video, one paragraph per line, with "[m:ss]"
  where the source has a timestamp. Names and terms are corrected.

THE CORRECTIONS POLICY

Auto-captions fail hardest on exactly the words somebody would search for.
Names and terms are corrected (the founder is Maceo Whatley, not "Miss
Watley"; the man who bought the pizzas is Laszlo Hanyecz). Speech is not:
the ums stay, the false starts stay, and where a person mishears a word on
camera, what they said stays. Where YouTube masked a word in its own captions
it appears as [bleeped].

WHAT THIS IS NOT

Not a verbatim court record. Auto-captions drop words, and the timestamps
are paragraph-level. For anything that matters, watch the video; every
transcript paragraph on the site links to its moment.

LICENCE

The text in this archive (videos.json, people.json, the transcripts) is
released under Creative Commons Attribution 4.0 (CC BY 4.0). Use it, quote
it, build on it, and credit We Them Media with a link to https://wethem.xyz.
The videos themselves remain on YouTube under YouTube's terms. The people in
the interviews said these things on camera in public; treat them as people.

CONTACT

wethem.xyz@gmail.com
